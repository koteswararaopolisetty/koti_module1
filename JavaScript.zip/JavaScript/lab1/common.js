var msg;
var sum;
msg="<p><code>The actual script is in external script file called common.js</code></p>"
function addNos(headVar,bodyVar)
{
	document.write(msg);
	sum=headVar+bodyVar;
	document.write("The sum of variables headVar and bodyVar is: "+sum);
}