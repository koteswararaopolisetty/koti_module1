function sayHello()
{
	document.write("<b>Hello World</b>");
}