document.write("<h2>Hello from the External Javascript File");

function ShowTime()
{
	var date = new Date();
	
	document.write(date);
}